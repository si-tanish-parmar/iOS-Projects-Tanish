//
//  ChildViewController.swift
//  ChildViewControllerAssignment
//
//  Created by Tanish Parmar on 04/11/23.
//

import UIKit

class ChildViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.red
        
    }
}
